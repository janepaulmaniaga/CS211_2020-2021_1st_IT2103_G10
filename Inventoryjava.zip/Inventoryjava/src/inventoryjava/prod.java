/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventoryjava;

/**
 *
 * @author Aron
 */
class prod {
    private int Id,Quantity;
    private String Name,Description,Category;
    public prod(int Id,String Name,int Quantity,String Description,String Category){
        this.Id = Id;
        this.Name = Name;
        this.Quantity = Quantity;
        this.Description = Description;
        this.Category = Category;
        
        
        
    }
    public int getId(){
        return  Id;
    }
    public String getName(){
        return  Name;
    }
    public int getQuantity(){
        return  Quantity;
    }
    public String getDescription(){
        return  Description;
    }
        public String getCategory(){
        return  Category;
     }
}
    
    

