/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventoryjava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Aron
 */
public class Orders extends javax.swing.JFrame {

   Connection con= null;
    ResultSet rs= null;
    PreparedStatement pst = null;
    public Orders() {
        initComponents();
        ShowOR();
        Show();
        ShowCUS();
        Date();
        
    }
   public ArrayList<order> ORD(){
        ArrayList<order> ORD = new ArrayList<>();
        try{
         Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
         String url = "jdbc:sqlserver://DESKTOP-CBF6I53;databaseName=db_INSYS;user = admin; password = user";
         Connection con = DriverManager.getConnection(url);
         String query2 = "select * from tbl_odd";
         Statement st = con.createStatement();
         ResultSet rs = st.executeQuery(query2);
         order ord;
         while (rs.next()){
             ord = new order(rs.getInt("Id"),rs.getString("Product"),rs.getInt("Quantity"),rs.getInt("Price"),rs.getInt("Total"));
       ORD.add(ord);
         }
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        return ORD; 
    }
    public void ShowOR(){
        ArrayList<order> list = ORD();
        DefaultTableModel model=(DefaultTableModel) Bill.getModel();
        Object[]row = new Object[5];
        for(int i=0;i<list.size();i++){
            row[0]=list.get(i).getId();
            row[1]=list.get(i).getProduct();
            row[2]=list.get(i).getPrice();
            row[3]=list.get(i).getQuantity();
            row[4]=list.get(i).getTotal();
            model.addRow(row);
        }
    }
    public ArrayList<prod> Products(){
        ArrayList<prod> Products = new ArrayList<>();
        try{
         Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
         String url ="jdbc:sqlserver://DESKTOP-CBF6I53;databaseName=db_INSYS;user = admin; password = user";
         Connection con = DriverManager.getConnection(url);
         String query1 = "select * from tbl_productt";
         Statement st = con.createStatement();
         ResultSet rs = st.executeQuery(query1);
         prod pro;
         while (rs.next()){
             pro=new prod (rs.getInt("ID"),rs.getString("Name"),rs.getInt("Quantity"),rs.getString("Description"),rs.getString("Category"));
       Products.add(pro);
         }
        
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        return Products; 
    }
    public void Show(){
        ArrayList<prod> list =Products();
        DefaultTableModel model=(DefaultTableModel) tbl1.getModel();
        Object[]row = new Object[5];
        for(int i=0;i<list.size();i++){
            row[0]=list.get(i).getId();
            row[1]=list.get(i).getName();
            row[2]=list.get(i).getQuantity();
            row[3]=list.get(i).getDescription();
            row[4]=list.get(i).getCategory();
            model.addRow(row);
        }
    }
     public ArrayList<cus> Customer(){
        ArrayList<cus> Customer = new ArrayList<>();
        try{
         Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
         String url ="jdbc:sqlserver://DESKTOP-CBF6I53;databaseName=db_INSYS;user = admin; password = user";
         Connection con = DriverManager.getConnection(url);
         String query1 = "select * from tbl_cus";
         Statement st = con.createStatement();
         ResultSet rs = st.executeQuery(query1);
         cus cust;
         while (rs.next()){
             cust =new cus (rs.getInt("Id"),rs.getString("Name"),rs.getInt("Phone"));
       Customer.add(cust);
         }
        
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        return Customer; 
    }
    public void ShowCUS(){
        ArrayList<cus> list = Customer();
        DefaultTableModel model=(DefaultTableModel) tbl4.getModel();
        Object[]row = new Object[3];
        for(int i=0;i<list.size();i++){
            row[0]=list.get(i).getCusId();
            row[1]=list.get(i).getCusName();
            row[2]=list.get(i).getPhone();
            
            model.addRow(row);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        ord1 = new javax.swing.JTextField();
        qty1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        Bill = new javax.swing.JTable();
        prin = new javax.swing.JButton();
        home = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl4 = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbl1 = new javax.swing.JTable();
        cn1 = new javax.swing.JLabel();
        dates = new javax.swing.JLabel();
        add = new javax.swing.JButton();
        prodname = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        UPrice = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        amt = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        area = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setPreferredSize(new java.awt.Dimension(500, 500));

        jLabel1.setText("OrderId");

        jLabel4.setText("CustomerName");

        jLabel9.setText("ProductName");

        jLabel10.setText("Quantity");

        Bill.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Product", "Quantity", "UPrice", "Total"
            }
        ));
        jScrollPane1.setViewportView(Bill);

        prin.setText("Print");
        prin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prinActionPerformed(evt);
            }
        });

        home.setText("HOME");
        home.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeActionPerformed(evt);
            }
        });

        tbl4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "CustomerName", "Phone"
            }
        ));
        tbl4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl4MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbl4);

        tbl1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Quantity", "Description", "Category"
            }
        ));
        tbl1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl1MouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tbl1);

        cn1.setText("_____________");

        dates.setText("date");

        add.setText("ADD");
        add.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addMouseClicked(evt);
            }
        });
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });

        jLabel2.setText("CUSTOMER LIST");

        jLabel3.setText("PRODUCT LIST");

        jLabel5.setText("UPrice");

        jLabel6.setText("AMOUNT:");

        amt.setText("AMOUNT");

        jButton1.setText("ADD TO ORDER");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel7.setText("ORDERS");

        area.setColumns(20);
        area.setRows(5);
        jScrollPane2.setViewportView(area);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(dates)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel10))
                                .addGap(48, 48, 48)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cn1, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ord1, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(prodname, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(qty1, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(UPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(46, 46, 46))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jButton1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(prin)
                                .addGap(30, 30, 30))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jScrollPane2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 516, Short.MAX_VALUE)
                                .addComponent(jScrollPane4)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel3)
                                    .addGap(211, 211, 211))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                    .addComponent(home)
                                    .addGap(13, 13, 13)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(211, 211, 211))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(237, 237, 237))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(add)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18)
                                .addComponent(amt)
                                .addGap(66, 66, 66)))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(dates)
                .addGap(11, 11, 11)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(ord1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cn1))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel9)
                                    .addComponent(prodname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel10)
                                    .addComponent(qty1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(UPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(20, 20, 20)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton1)
                                    .addComponent(prin)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel3)
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(add)
                            .addComponent(jLabel6)
                            .addComponent(amt))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                        .addComponent(home))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 777, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 597, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tbl4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl4MouseClicked
        try{DefaultTableModel model =(DefaultTableModel)tbl4.getModel();
            int selectedRowIndex = tbl4.getSelectedRow();
            cn1.setText(model.getValueAt(selectedRowIndex,1).toString());
           

        }catch(Exception e){

        }
    }//GEN-LAST:event_tbl4MouseClicked

    private void tbl1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl1MouseClicked
        DefaultTableModel model =(DefaultTableModel)tbl1.getModel();
            int selectedRowIndex = tbl1.getSelectedRow();
            prodname.setText(model.getValueAt(selectedRowIndex,1).toString());
         
    }//GEN-LAST:event_tbl1MouseClicked

    private void addMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addMouseClicked
      
    }//GEN-LAST:event_addMouseClicked

    private void homeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeActionPerformed
        new HomeForm().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_homeActionPerformed

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
     try{ 
        double a = Double.parseDouble(UPrice.getText());
        int b = Integer.parseInt(qty1.getText());
        double amot = a*b;
        amt.setText(""+amot);
     }catch (Exception e){
         
     }
        
    }//GEN-LAST:event_addActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url = "jdbc:sqlserver://DESKTOP-CBF6I53;databaseName=db_INSYS;user = admin; password = user";
            Connection con = DriverManager.getConnection(url);
            int row = Bill.getSelectedRow();     
            String query = "insert into tbl_odd (Id,Product,Quantity,Price,Total)values (?,?,?,?,?)";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1,ord1.getText());    
            pst.setString(2,prodname.getText());
            pst.setString(3,qty1.getText());
            pst.setString(4,UPrice.getText());
            pst.setString(5,amt.getText()); 
            pst.executeUpdate();
            DefaultTableModel model = (DefaultTableModel)Bill.getModel();
            model.setRowCount(0);
            ShowOR();
            JOptionPane.showMessageDialog(null,"Successfully Added to Orders hahaha!");  
            
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,e); 
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void prinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prinActionPerformed
        area.setText("*******************************************\n");
        area.setText(area.getText()+"*                        RECIEPT                           *\n");
        area.setText(area.getText()+"*******************************************\n");
        area.setText(area.getText()+"\n"+dates.getText()+"\n\n");
        area.setText(area.getText()+"CUSTOMER:  "+cn1.getText()+"\n\n");
        area.setText(area.getText()+"PRODUCT:  "+prodname.getText()+"\n\n");
        area.setText(area.getText()+"QUANTITY:  "+qty1.getText()+"\n\n");
        area.setText(area.getText()+"PRICE:  "+UPrice.getText()+"\n\n");
        area.setText(area.getText()+"*******************************************\n");
        area.setText(area.getText()+"*                       SIGNITURE                        *\n\n");
        area.setText(area.getText()+"*******************************************\n");
    }//GEN-LAST:event_prinActionPerformed
     void Date() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        dates.setText(dtf.format(now));
    }
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Orders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Orders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Orders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Orders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Orders().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Bill;
    private javax.swing.JTextField UPrice;
    private javax.swing.JButton add;
    private javax.swing.JLabel amt;
    private javax.swing.JTextArea area;
    private javax.swing.JLabel cn1;
    private javax.swing.JLabel dates;
    private javax.swing.JButton home;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField ord1;
    private javax.swing.JButton prin;
    private javax.swing.JTextField prodname;
    private javax.swing.JTextField qty1;
    private javax.swing.JTable tbl1;
    private javax.swing.JTable tbl4;
    // End of variables declaration//GEN-END:variables

   
}
