/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventoryjava;

/**
 *
 * @author Aron
 */
class users {
     
    private String Username,Password;
    public users (String Username,String Password){
        this.Username = Username;
        this.Password = Password;
     }
    public String getUsername(){
        return  Username;
    }
    public String getPassword(){
        return  Password;
    }
    
}
