/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventoryjava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

/**
 *
 * @author Aron
 */
public class Db {
    static private Connection c;
    
    public static Connection getCon() throws Exception {
        if (c ==null){
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            c =DriverManager.getConnection("jdbc:sqlserver://DESKTOP-CBF6I53;databaseName=db_INSYS;user = admin; password = user");
        }
        return c;
    } 
    public static void setData(String s) throws Exception {
        Db.getCon().createStatement().executeUpdate(s);
    }
    public static ResultSet getData (String sq) throws Exception {
        return Db.getCon().createStatement().executeQuery(sq);
    }
}
