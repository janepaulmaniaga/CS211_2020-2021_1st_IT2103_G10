/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventoryjava;

/**
 *
 * @author Aron
 */
 class cats {
     private int CatId;
    private String CatName;
    public cats(int CatId,String CatName){
        this.CatId = CatId;
        this.CatName = CatName;
     }
    public int getCatId(){
        return  CatId;
    }
    public String getCatName(){
        return  CatName;
    }
 }
