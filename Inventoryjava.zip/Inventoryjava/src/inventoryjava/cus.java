/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventoryjava;

/**
 *
 * @author Aron
 */
class cus {
    private int Id;
    private long Phone;
    private String Name;
    public cus(int Id,String Name,long Phone){
        this.Id = Id;
        this.Name = Name;
        this.Phone = Phone;
     }
    public int getCusId(){
        return  Id;
    }
    public String getCusName(){
        return  Name;
    }
    public long getPhone(){
        return  Phone;
    }
}
